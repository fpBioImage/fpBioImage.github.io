-------- FPBioimage Viewer -----------


INSTALLATION
------------
To install, simply unzip the contents of this folder into another location. 

To use FPBioimage Viewer with the FIJI or ImageJ plugin, make sure the unzip location doesn't require admin privileges. 


SYSTEM REQUIREMENTS
-------------------
Currently only supports Windows, but support for Mac OSX and Linux is coming soon!

The better the graphics card you use, the faster the 3D rendering will be! 