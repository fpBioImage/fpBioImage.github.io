-------- FPBioimage Viewer -----------


INSTALLATION
------------
To install, simply unzip the contents of this folder into another location. 

To use FPBioimage Viewer with the FIJI or ImageJ plugin, make sure the unzip location doesn't require admin privileges. 


SYSTEM REQUIREMENTS
-------------------
Designed for Windows 10, but should work fine on older versions of Windows. 

The better the graphics card you use, the faster the 3D rendering will be! 