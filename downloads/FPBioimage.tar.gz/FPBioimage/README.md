# FPBioimage for Linux
## Installation instructions
Extract, then install:
```
tar -xvzf FPBioimage.tar.gz
cd FPBioimage
sudo make install
```

### Advanced installation notes
By default, FPBioimage is installed to `/usr/local/fpbioimage`, which is where the FPBioimage plugin for ImageJ will look for it by default.

To install to a different location, unzip the tarball and copy the entire contents to a location of your choice. Then, make sure the binary file is executable with `chmod -x FPBioimage-4.5.0.x86_64`.
